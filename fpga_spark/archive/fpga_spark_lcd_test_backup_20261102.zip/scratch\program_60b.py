import subprocess
import sys
import os

programmer_exe = r"D:\Gowin\Gowin_V1.9.12.04_x64\Programmer\bin\programmer_cli.exe"
fs_file = r"C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\scratch\test_60b_build\impl\pnr\test_60b.fs"

if not os.path.exists(fs_file):
    print(f"Error: Bitstream {fs_file} not found!")
    sys.exit(1)

cmd = [
    programmer_exe,
    "--device", "GW5AT-60B",
    "--run", "2",
    "--fsFile", fs_file
]

print("Executing:", " ".join(cmd))
res = subprocess.run(cmd, capture_output=True, text=True)
print(res.stdout)
if res.stderr:
    print("STDERR:", res.stderr)
sys.exit(res.returncode)

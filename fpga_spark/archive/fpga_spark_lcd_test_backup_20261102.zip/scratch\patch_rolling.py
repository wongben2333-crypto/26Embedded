path = r"C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\visualizer\rolling_waveform.v"
with open(path, "r", encoding="utf-8") as f:
    c = f.read()

target1 = "wire [ADDR_BITS-1:0] visible_count = available > WIDTH ? WIDTH : available;"
replacement1 = "wire [ADDR_BITS-1:0] visible_count = (available > WIDTH) ? WIDTH[ADDR_BITS-1:0] : available[ADDR_BITS-1:0];"

target2 = "phase <= next_phase - PHASE_LIMIT;"
replacement2 = "phase <= next_phase[31:0] - PHASE_LIMIT[31:0];"

target3 = "phase <= next_phase; peak <= next_peak; partial_valid <= 1;"
replacement3 = "phase <= next_phase[31:0]; peak <= next_peak; partial_valid <= 1;"

c_norm = c.replace("\r\n", "\n")
assert target1 in c_norm
assert target2 in c_norm
assert target3 in c_norm

c_norm = c_norm.replace(target1, replacement1)
c_norm = c_norm.replace(target2, replacement2)
c_norm = c_norm.replace(target3, replacement3)

with open(path, "w", encoding="utf-8", newline="\r\n") as f:
    f.write(c_norm)

print("SUCCESS: rolling_waveform.v patched")

set root [file dirname [info script]]
cd $root
open_project test_60b.gprj
set_option -top_module lcd_test_top
set_option -synthesis_tool gowinsynthesis
set_option -output_base_name test_60b
set_option -verilog_std sysv2017
run all
exit

path = r"C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\lcd_test_top.v"
with open(path, "r", encoding="utf-8") as f:
    c = f.read()

target = """    wire [8:0] wave0_col = (px < 10'd20) ? 9'd0 :
                          (px >= 10'd439) ? 9'd419 : px - 10'd20;
    wire [9:0] wave1_col = (px < 10'd20) ? 10'd0 :
                          (px >= 10'd777) ? 10'd757 : px - 10'd20;
    wire [4:0] spectrum_col = (px >= 10'd36 && px <= 10'd764) ?
                             ((px - 10'd36) / 10'd23) : 5'd0;"""

replacement = """    wire [8:0] wave0_col = (px < 10'd20) ? 9'd0 :
                          (px >= 10'd439) ? 9'd419 : (px[8:0] - 9'd20);
    wire [9:0] wave1_col = (px < 10'd20) ? 10'd0 :
                          (px >= 10'd777) ? 10'd757 : (px - 10'd20);
    wire [9:0] px_spec_offset = (px >= 10'd36) ? (px - 10'd36) : 10'd0;
    wire [21:0] spec_prod = px_spec_offset * 12'd2850;
    wire [4:0] spectrum_col = (px >= 10'd36 && px <= 10'd764) ? spec_prod[20:16] : 5'd0;"""

c_norm = c.replace("\r\n", "\n")
target_norm = target.replace("\r\n", "\n")
assert target_norm in c_norm

c_norm = c_norm.replace(target_norm, replacement.replace("\r\n", "\n"))

with open(path, "w", encoding="utf-8", newline="\r\n") as f:
    f.write(c_norm)

print("SUCCESS: lcd_test_top.v patched")

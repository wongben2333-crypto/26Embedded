import re

# 1. Optimize piano_engine.v
p_pe = r'C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\synth\piano_engine.v'
with open(p_pe, 'r', encoding='utf-8') as f:
    pe = f.read()

old_u1 = '    reg [18:0]        uni_q;                  // 齐奏拍频系数（Q16）'
new_u1 = '    reg [15:0]        uni_q;                  // 齐奏拍频系数（Q16, 0.25..0.75 fits in 16 bits）'
assert old_u1 in pe, 'old_u1 not found'
pe = pe.replace(old_u1, new_u1, 1)

old_mod = '''    wire [31:0] inc_vib [0:N_PART-1];
    generate
    for (gn = 0; gn < N_PART; gn = gn + 1) begin : g_modinc
        localparam integer NP = gn + 1;
        wire [32:0] f0e = {1'b0, f0_mod_r};
        wire [32:0] nf0 = (NP == 1) ?  f0e                    :
                          (NP == 2) ? (f0e << 1)              :
                          (NP == 3) ? ((f0e << 1) + f0e)      :
                          (NP == 4) ? (f0e << 2)              :
                          (NP == 5) ? ((f0e << 2) + f0e)      :
                                      ((f0e << 2) + (f0e << 1));
        assign inc_vib[gn] = nf0 + (f0e >> cf_st1[gn]) + (f0e >> cf_st2[gn]);
    end
    endgenerate

    // ★ 回归开关：表情关闭时走原来的 inc[]（逐位一致）
    // ★ inc_vib 先打一拍：这样"调制链(乘法+6 路移位加法)"与"相位累加器"之间
    //   多了一级寄存器，相位累加器输入只剩一个 mux。
    //   表情关闭时 mux 选 inc[j] ⇒ 与原通路**逐位相同**，回归不受影响。
    reg [PHASE_W-1:0] inc_vib_r [0:N_PART-1];
    integer           ij;                     // ⚠️ 不能用 j：j 在本模块更靠后才声明
    always @(posedge clk) begin
        if (!rst_n)
            for (ij = 0; ij < N_PART; ij = ij + 1) inc_vib_r[ij] <= {PHASE_W{1'b0}};
        else
            for (ij = 0; ij < N_PART; ij = ij + 1) inc_vib_r[ij] <= inc_vib[ij];
    end'''

new_mod = '''    // 6 泛音调制增量时分共享单套移位加法器（每声部 6 拍轮询更新，远快于 512 拍 sample_tick）
    reg [2:0] mod_idx;
    always @(posedge clk) begin
        if (!rst_n) mod_idx <= 3'd0;
        else        mod_idx <= (mod_idx == 3'd5) ? 3'd0 : (mod_idx + 3'd1);
    end
    wire [32:0] f0e_m = {1'b0, f0_mod_r};
    wire [32:0] nf0_m = (mod_idx == 3'd0) ?  f0e_m                      :
                        (mod_idx == 3'd1) ? (f0e_m << 1)                :
                        (mod_idx == 3'd2) ? ((f0e_m << 1) + f0e_m)      :
                        (mod_idx == 3'd3) ? (f0e_m << 2)                :
                        (mod_idx == 3'd4) ? ((f0e_m << 2) + f0e_m)      :
                                            ((f0e_m << 2) + (f0e_m << 1));
    wire [32:0] st1_m = (mod_idx == 3'd0) ? (f0e_m >> cf_st1[0]) :
                        (mod_idx == 3'd1) ? (f0e_m >> cf_st1[1]) :
                        (mod_idx == 3'd2) ? (f0e_m >> cf_st1[2]) :
                        (mod_idx == 3'd3) ? (f0e_m >> cf_st1[3]) :
                        (mod_idx == 3'd4) ? (f0e_m >> cf_st1[4]) :
                                            (f0e_m >> cf_st1[5]);
    wire [32:0] st2_m = (mod_idx == 3'd0) ? (f0e_m >> cf_st2[0]) :
                        (mod_idx == 3'd1) ? (f0e_m >> cf_st2[1]) :
                        (mod_idx == 3'd2) ? (f0e_m >> cf_st2[2]) :
                        (mod_idx == 3'd3) ? (f0e_m >> cf_st2[3]) :
                        (mod_idx == 3'd4) ? (f0e_m >> cf_st2[4]) :
                                            (f0e_m >> cf_st2[5]);
    wire [31:0] inc_vib_cur = nf0_m + st1_m + st2_m;

    reg [PHASE_W-1:0] inc_vib_r [0:N_PART-1];
    integer           ij;
    always @(posedge clk) begin
        if (!rst_n)
            for (ij = 0; ij < N_PART; ij = ij + 1) inc_vib_r[ij] <= {PHASE_W{1'b0}};
        else
            inc_vib_r[mod_idx] <= inc_vib_cur;
    end'''

assert old_mod in pe, 'old_mod not found'
pe = pe.replace(old_mod, new_mod, 1)

old_env = '''    // 噪声样点（显式 signed：拼接结果是无符号的，必须先转换再参与有符号减法）
    wire signed [17:0] nz_s = {{2{lfsr[31]}}, lfsr[31:16]};'''

new_env = '''    // 噪声样点（显式 signed：拼接结果是无符号的，必须先转换再参与有符号减法）
    wire signed [17:0] nz_s = {{2{lfsr[31]}}, lfsr[31:16]};

    // 每泛音共享单套 32-bit 衰减减法器、底噪比较器与弓弦加法器（逐位等价，省 ~4,600 ALU）
    wire [ENV_W-1:0] env_next_val [0:N_PART-1];
    generate
    for (gn = 0; gn < N_PART; gn = gn + 1) begin : g_env_alu
        wire [31:0] env_sh   = (!gate_r) ? (env[gn] >> cf_sd[gn]) : (env[gn] >> cf_sr[gn]);
        wire [31:0] env_thr  = (!gate_r) ? (32'd1 << cf_sd[gn])   : (32'd1 << cf_sr[gn]);
        wire        env_flr  = (env[gn] <= env_thr);
        wire [31:0] env_dec  = env[gn] - env_sh;
        wire        env_ramp = (env_sh < drv_q);
        wire [31:0] env_base = env_ramp ? env[gn] : env_dec;
        wire [31:0] env_add  = env_ramp ? drv_r4  : drv_q;
        wire [31:0] env_drv  = env_base + env_add;
        assign env_next_val[gn] = (gate_r && drv_act) ? env_drv : (env_flr ? 32'd0 : env_dec);
    end
    endgenerate'''

assert old_env in pe, 'old_env not found'
pe = pe.replace(old_env, new_env, 1)

old_env_loop = '''                for (j = 0; j < N_PART; j = j + 1) begin
                    if (!gate_r) begin
                        if (env[j] <= (32'd1 << cf_sd[j]))
                            env[j] <= 32'd0;
                        else
                            env[j] <= env[j] - (env[j] >> cf_sd[j]);
                    end else if (env_en) begin
                        if (drv_act && ((env[j] >> cf_sr[j]) < drv_q))
                            env[j] <= env[j] + drv_r4;                       // 定速斜坡（常量左移）
                        else if (drv_act)
                            env[j] <= env[j] - (env[j] >> cf_sr[j]) + drv_q; // 稳态
                        else begin
                            if (env[j] <= (32'd1 << cf_sr[j]))
                                env[j] <= 32'd0;
                            else
                                env[j] <= env[j] - (env[j] >> cf_sr[j]);     // 钢琴/吉他：自然衰减到底直接归零
                        end
                    end
                end'''

new_env_loop = '''                for (j = 0; j < N_PART; j = j + 1) begin
                    if (!gate_r || env_en)
                        env[j] <= env_next_val[j];
                end'''

assert old_env_loop in pe, 'old_env_loop not found'
pe = pe.replace(old_env_loop, new_env_loop, 1)

old_u2 = '''            uni_q    <= 19'd0;
        end else begin
            for (j = 0; j < N_PART; j = j + 1)
                prod[j] <= $signed(pf[j][34:16]);   // 等价于 >>> 16（有符号）
            ham_prod <= $signed(hpf[36:16]);
            uni_q    <= uni_calc[18:0];             // 正值，0.25..0.75 Q16
        end
    end

    // ------------------------------------------------------- 流水第三级 -----
    reg signed [21:0] psum;
    always @(*) begin
        psum = 22'sd0;
        for (j = 0; j < N_PART; j = j + 1)
            psum = psum + prod[j];
    end

    // 22 bit × 19 bit → 41 bit（全宽）→ >>16 ⇒ 取 [40:16]
    wire signed [40:0] vmul = psum * $signed({1'b0, uni_q});

    // ★★ 位选（part-select）在 Verilog 里【永远是无符号】的 ★★
    //   写成 `vmul[40:16] + ham_prod` 时，因为左操作数无符号，整个加法被当成
    //   无符号运算：负的 ham_prod 会被【零扩展】成一个大正数加进去，
    //   结果是输出被顶到 +32767 恒削顶（本项目实测：单音 RMS 直接爆表、
    //   松键后电平反而更大 —— 因为噪声项的符号全错）。
    //   必须用 $signed() 把位选恢复成有符号再相加。
    wire signed [24:0] vscale = $signed(vmul[40:16]);'''

new_u2 = '''            uni_q    <= 16'd0;
        end else begin
            for (j = 0; j < N_PART; j = j + 1)
                prod[j] <= $signed(pf[j][34:16]);   // 等价于 >>> 16（有符号）
            ham_prod <= $signed(hpf[36:16]);
            uni_q    <= uni_calc[15:0];             // 正值，0.25..0.75 Q16 (16384..49151)
        end
    end

    // ------------------------------------------------------- 流水第三级 -----
    reg signed [21:0] psum;
    always @(*) begin
        psum = 22'sd0;
        for (j = 0; j < N_PART; j = j + 1)
            psum = psum + prod[j];
    end

    // 22 bit × 17 bit → 39 bit（单颗 MULTALU27X18 即可容纳，省 8 颗 DSP）→ >>16
    wire signed [38:0] vmul = psum * $signed({1'b0, uni_q});
    wire signed [24:0] vscale = $signed({{2{vmul[38]}}, vmul[38:16]});'''

assert old_u2 in pe, 'old_u2 not found'
pe = pe.replace(old_u2, new_u2, 1)

with open(p_pe, 'w', encoding='utf-8') as f:
    f.write(pe)
print('Updated piano_engine.v successfully.')

# 2. Restore N_VOICES=8 in lcd_test_top.v
p_top = r'C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\lcd_test_top.v'
with open(p_top, 'r', encoding='utf-8') as f:
    top = f.read()

top = top.replace('wire [3:0]         piano_active;', 'wire [7:0]         piano_active;')
top = top.replace('.N_VOICES  (4),', '.N_VOICES  (8),')
with open(p_top, 'w', encoding='utf-8') as f:
    f.write(top)
print('Restored N_VOICES=8 in lcd_test_top.v.')

# 3. Optimize lcd_ui.v
p_ui = r'C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\lcd_ui.v'
with open(p_ui, 'r', encoding='utf-8') as f:
    ui = f.read()

# Merge conditional text_pixel pairs first
old_pair1 = '''    wire t_p0_c2_v1 = (page == 2'd0) && (audio_active ?
        text_pixel(10, px, py, 10'd286, 9'd68, 2'd1) :
        text_pixel(11, px, py, 10'd286, 9'd68, 2'd1));'''
new_pair1 = '''    wire t_p0_c2_v1 = (page == 2'd0) && text_pixel(audio_active ? 7'd10 : 7'd11, px, py, 10'd286, 9'd68, 2'd1);'''
assert old_pair1 in ui, 'old_pair1 not found'
ui = ui.replace(old_pair1, new_pair1, 1)

old_pair2 = '''    wire t_p0_piano_hdr = (page == 2'd0) && (any_key_active ?
        text_pixel(23, px, py, 10'd468, 9'd302, 2'd1) :
        text_pixel(24, px, py, 10'd468, 9'd302, 2'd1));'''
new_pair2 = '''    wire t_p0_piano_hdr = (page == 2'd0) && text_pixel(any_key_active ? 7'd23 : 7'd24, px, py, 10'd468, 9'd302, 2'd1);'''
assert old_pair2 in ui, 'old_pair2 not found'
ui = ui.replace(old_pair2, new_pair2, 1)

# Replace Page 3 8x parallel get_song_note + 16x note_to_y with single active-slot lookup
old_p3_notes = '''    wire [6:0] s_note_0 = get_song_note(song_index, s_idx_0);
    wire [6:0] s_note_1 = get_song_note(song_index, s_idx_1);
    wire [6:0] s_note_2 = get_song_note(song_index, s_idx_2);
    wire [6:0] s_note_3 = get_song_note(song_index, s_idx_3);
    wire [6:0] s_note_4 = get_song_note(song_index, s_idx_4);
    wire [6:0] s_note_5 = get_song_note(song_index, s_idx_5);
    wire [6:0] s_note_6 = get_song_note(song_index, s_idx_6);
    wire [6:0] s_note_7 = get_song_note(song_index, s_idx_7);

    wire [8:0] s_y_0 = note_to_y(s_note_0);
    wire [8:0] s_y_1 = note_to_y(s_note_1);
    wire [8:0] s_y_2 = note_to_y(s_note_2);
    wire [8:0] s_y_3 = note_to_y(s_note_3);
    wire [8:0] s_y_4 = note_to_y(s_note_4);
    wire [8:0] s_y_5 = note_to_y(s_note_5);
    wire [8:0] s_y_6 = note_to_y(s_note_6);
    wire [8:0] s_y_7 = note_to_y(s_note_7);

    wire [8:0] s_yb_0 = note_to_y(s_note_0 >= 7'd60 ? (s_note_0 - 7'd12) : s_note_0);
    wire [8:0] s_yb_1 = note_to_y(s_note_1 >= 7'd60 ? (s_note_1 - 7'd12) : s_note_1);
    wire [8:0] s_yb_2 = note_to_y(s_note_2 >= 7'd60 ? (s_note_2 - 7'd12) : s_note_2);
    wire [8:0] s_yb_3 = note_to_y(s_note_3 >= 7'd60 ? (s_note_3 - 7'd12) : s_note_3);
    wire [8:0] s_yb_4 = note_to_y(s_note_4 >= 7'd60 ? (s_note_4 - 7'd12) : s_note_4);
    wire [8:0] s_yb_5 = note_to_y(s_note_5 >= 7'd60 ? (s_note_5 - 7'd12) : s_note_5);
    wire [8:0] s_yb_6 = note_to_y(s_note_6 >= 7'd60 ? (s_note_6 - 7'd12) : s_note_6);
    wire [8:0] s_yb_7 = note_to_y(s_note_7 >= 7'd60 ? (s_note_7 - 7'd12) : s_note_7);

    // Continuous X coordinates: 360 + (slot - 2)*60 - sub_scroll
    wire signed [11:0] s_x_0 = 12'sd240 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_1 = 12'sd300 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_2 = 12'sd360 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_3 = 12'sd420 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_4 = 12'sd480 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_5 = 12'sd540 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_6 = 12'sd600 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_7 = 12'sd660 - $signed({6'd0, song_sub_scroll});

    wire signed [11:0] px_s = $signed({2'b00, px});

    wire hit_m_0 = (page == 2'd3) && (s_y_0 != 9'd0) && (px_s >= s_x_0 - 12'sd18 && px_s <= s_x_0 + 12'sd18) && (py >= s_y_0 - 9'd7 && py <= s_y_0 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_1 = (page == 2'd3) && (s_y_1 != 9'd0) && (px_s >= s_x_1 - 12'sd18 && px_s <= s_x_1 + 12'sd18) && (py >= s_y_1 - 9'd7 && py <= s_y_1 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_2 = (page == 2'd3) && (s_y_2 != 9'd0) && (px_s >= s_x_2 - 12'sd18 && px_s <= s_x_2 + 12'sd18) && (py >= s_y_2 - 9'd7 && py <= s_y_2 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_3 = (page == 2'd3) && (s_y_3 != 9'd0) && (px_s >= s_x_3 - 12'sd18 && px_s <= s_x_3 + 12'sd18) && (py >= s_y_3 - 9'd7 && py <= s_y_3 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_4 = (page == 2'd3) && (s_y_4 != 9'd0) && (px_s >= s_x_4 - 12'sd18 && px_s <= s_x_4 + 12'sd18) && (py >= s_y_4 - 9'd7 && py <= s_y_4 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_5 = (page == 2'd3) && (s_y_5 != 9'd0) && (px_s >= s_x_5 - 12'sd18 && px_s <= s_x_5 + 12'sd18) && (py >= s_y_5 - 9'd7 && py <= s_y_5 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_6 = (page == 2'd3) && (s_y_6 != 9'd0) && (px_s >= s_x_6 - 12'sd18 && px_s <= s_x_6 + 12'sd18) && (py >= s_y_6 - 9'd7 && py <= s_y_6 + 9'd7) && (px >= 10'd32 && px <= 10'd764);
    wire hit_m_7 = (page == 2'd3) && (s_y_7 != 9'd0) && (px_s >= s_x_7 - 12'sd18 && px_s <= s_x_7 + 12'sd18) && (py >= s_y_7 - 9'd7 && py <= s_y_7 + 9'd7) && (px >= 10'd32 && px <= 10'd764);

    wire hit_b_0 = (page == 2'd3) && (s_yb_0 != 9'd0) && (px_s >= s_x_0 - 12'sd22 && px_s <= s_x_0 + 12'sd22) && (py >= s_yb_0 - 9'd6 && py <= s_yb_0 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_1 = (page == 2'd3) && (s_yb_1 != 9'd0) && (px_s >= s_x_1 - 12'sd22 && px_s <= s_x_1 + 12'sd22) && (py >= s_yb_1 - 9'd6 && py <= s_yb_1 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_2 = (page == 2'd3) && (s_yb_2 != 9'd0) && (px_s >= s_x_2 - 12'sd22 && px_s <= s_x_2 + 12'sd22) && (py >= s_yb_2 - 9'd6 && py <= s_yb_2 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_3 = (page == 2'd3) && (s_yb_3 != 9'd0) && (px_s >= s_x_3 - 12'sd22 && px_s <= s_x_3 + 12'sd22) && (py >= s_yb_3 - 9'd6 && py <= s_yb_3 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_4 = (page == 2'd3) && (s_yb_4 != 9'd0) && (px_s >= s_x_4 - 12'sd22 && px_s <= s_x_4 + 12'sd22) && (py >= s_yb_4 - 9'd6 && py <= s_yb_4 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_5 = (page == 2'd3) && (s_yb_5 != 9'd0) && (px_s >= s_x_5 - 12'sd22 && px_s <= s_x_5 + 12'sd22) && (py >= s_yb_5 - 9'd6 && py <= s_yb_5 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_6 = (page == 2'd3) && (s_yb_6 != 9'd0) && (px_s >= s_x_6 - 12'sd22 && px_s <= s_x_6 + 12'sd22) && (py >= s_yb_6 - 9'd6 && py <= s_yb_6 + 9'd6) && (px >= 10'd32 && px <= 10'd764);
    wire hit_b_7 = (page == 2'd3) && (s_yb_7 != 9'd0) && (px_s >= s_x_7 - 12'sd22 && px_s <= s_x_7 + 12'sd22) && (py >= s_yb_7 - 9'd6 && py <= s_yb_7 + 9'd6) && (px >= 10'd32 && px <= 10'd764);'''

new_p3_notes = '''    // Continuous X coordinates: 360 + (slot - 2)*60 - sub_scroll (spaced 60px apart; width <= 45px, never overlap)
    wire signed [11:0] s_x_0 = 12'sd240 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_1 = 12'sd300 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_2 = 12'sd360 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_3 = 12'sd420 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_4 = 12'sd480 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_5 = 12'sd540 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_6 = 12'sd600 - $signed({6'd0, song_sub_scroll});
    wire signed [11:0] s_x_7 = 12'sd660 - $signed({6'd0, song_sub_scroll});

    wire signed [11:0] px_s = $signed({2'b00, px});
    wire in_sx_0 = (px_s >= s_x_0 - 12'sd22) && (px_s <= s_x_0 + 12'sd22);
    wire in_sx_1 = (px_s >= s_x_1 - 12'sd22) && (px_s <= s_x_1 + 12'sd22);
    wire in_sx_2 = (px_s >= s_x_2 - 12'sd22) && (px_s <= s_x_2 + 12'sd22);
    wire in_sx_3 = (px_s >= s_x_3 - 12'sd22) && (px_s <= s_x_3 + 12'sd22);
    wire in_sx_4 = (px_s >= s_x_4 - 12'sd22) && (px_s <= s_x_4 + 12'sd22);
    wire in_sx_5 = (px_s >= s_x_5 - 12'sd22) && (px_s <= s_x_5 + 12'sd22);
    wire in_sx_6 = (px_s >= s_x_6 - 12'sd22) && (px_s <= s_x_6 + 12'sd22);
    wire in_sx_7 = (px_s >= s_x_7 - 12'sd22) && (px_s <= s_x_7 + 12'sd22);

    wire [8:0] sel_s_idx = in_sx_0 ? s_idx_0 : in_sx_1 ? s_idx_1 : in_sx_2 ? s_idx_2 : in_sx_3 ? s_idx_3 :
                           in_sx_4 ? s_idx_4 : in_sx_5 ? s_idx_5 : in_sx_6 ? s_idx_6 : s_idx_7;
    wire signed [11:0] sel_s_x = in_sx_0 ? s_x_0 : in_sx_1 ? s_x_1 : in_sx_2 ? s_x_2 : in_sx_3 ? s_x_3 :
                                 in_sx_4 ? s_x_4 : in_sx_5 ? s_x_5 : in_sx_6 ? s_x_6 : s_x_7;

    wire [6:0] sel_s_note = get_song_note(song_index, sel_s_idx);
    wire [8:0] sel_s_y    = note_to_y(sel_s_note);
    wire [8:0] sel_s_yb   = note_to_y(sel_s_note >= 7'd60 ? (sel_s_note - 7'd12) : sel_s_note);

    wire hit_m_common = (page == 2'd3) && (sel_s_y != 9'd0) &&
                        (px_s >= sel_s_x - 12'sd18 && px_s <= sel_s_x + 12'sd18) &&
                        (py >= sel_s_y - 9'd7 && py <= sel_s_y + 9'd7) &&
                        (px >= 10'd32 && px <= 10'd764);
    wire hit_b_common = (page == 2'd3) && (sel_s_yb != 9'd0) &&
                        (px_s >= sel_s_x - 12'sd22 && px_s <= sel_s_x + 12'sd22) &&
                        (py >= sel_s_yb - 9'd6 && py <= sel_s_yb + 9'd6) &&
                        (px >= 10'd32 && px <= 10'd764);

    wire hit_m_0 = in_sx_0 && hit_m_common;
    wire hit_m_1 = in_sx_1 && hit_m_common;
    wire hit_m_2 = in_sx_2 && hit_m_common;
    wire hit_m_3 = in_sx_3 && hit_m_common;
    wire hit_m_4 = in_sx_4 && hit_m_common;
    wire hit_m_5 = in_sx_5 && hit_m_common;
    wire hit_m_6 = in_sx_6 && hit_m_common;
    wire hit_m_7 = in_sx_7 && hit_m_common;

    wire hit_b_0 = in_sx_0 && hit_b_common;
    wire hit_b_1 = in_sx_1 && hit_b_common;
    wire hit_b_2 = in_sx_2 && hit_b_common;
    wire hit_b_3 = in_sx_3 && hit_b_common;
    wire hit_b_4 = in_sx_4 && hit_b_common;
    wire hit_b_5 = in_sx_5 && hit_b_common;
    wire hit_b_6 = in_sx_6 && hit_b_common;
    wire hit_b_7 = in_sx_7 && hit_b_common;'''

assert old_p3_notes in ui, 'old_p3_notes not found'
ui = ui.replace(old_p3_notes, new_p3_notes, 1)

# Now replace the 78 text_pixel calls with bounding-box checks + 1 shared text renderer
pattern = re.compile(r'wire\s+(\w+)\s*=\s*(\(page\s*==\s*2\'d\d\)\s*&&\s*)?text_pixel\(\s*([^,]+),\s*px,\s*py,\s*([^,]+),\s*([^,]+),\s*([^)]+)\);')
matches = list(pattern.finditer(ui))
print('Found text_pixel wire declarations:', len(matches))
assert len(matches) == 78, f'Expected 78 matches, got {len(matches)}'

# Replace text_pixel function with text_box
old_tp_fn = '''    function text_pixel;
        input [6:0] str_id;
        input [9:0] curr_x, curr_y;
        input [9:0] start_x, start_y;
        input [1:0] scale; // 1: 5x7, 2: 10x14
        reg [9:0] rx, ry;
        reg [9:0] char_idx;
        reg [5:0] s_len;
        reg [7:0] ch;
        reg [2:0] c_col, c_row;
        begin
            text_pixel = 1'b0;
            s_len = get_str_len(str_id);
            if (curr_x >= start_x && curr_y >= start_y) begin
                rx = (curr_x - start_x) / scale;
                ry = (curr_y - start_y) / scale;
                if (ry < 10'd7 && rx < ({4'd0, s_len} * 10'd6)) begin
                    char_idx = rx / 10'd6;
                    c_col = rx % 10'd6;
                    c_row = ry[2:0];
                    if (c_col < 3'd5) begin
                        ch = get_char(str_id, char_idx[5:0]);
                        if (ch != 8'd0) begin
                            text_pixel = font_dot(ch, c_col, c_row);
                        end
                    end
                end
            end
        end
    endfunction'''

new_tp_fn = '''    function text_box;
        input [6:0] str_id;
        input [9:0] curr_x, curr_y;
        input [9:0] start_x, start_y;
        input [1:0] scale; // 1: 5x7, 2: 10x14
        reg [9:0] w_px;
        reg [8:0] h_px;
        begin
            w_px = (scale == 2'd2) ? ({4'd0, get_str_len(str_id)} * 10'd12) : ({4'd0, get_str_len(str_id)} * 10'd6);
            h_px = (scale == 2'd2) ? 9'd14 : 9'd7;
            text_box = (curr_x >= start_x) && (curr_x < start_x + w_px) &&
                       (curr_y >= start_y) && (curr_y < start_y + h_px);
        end
    endfunction'''

assert old_tp_fn in ui, 'old_tp_fn not found'
ui = ui.replace(old_tp_fn, new_tp_fn, 1)

# Transform each wire t_xxx into wire b_xxx = ... text_box(...); wire t_xxx = b_xxx && shared_text_on;
box_entries = []
def repl_tp(m):
    wname = m.group(1)
    pg_cond = m.group(2) or ''
    sid = m.group(3).strip()
    sx = m.group(4).strip()
    sy = m.group(5).strip()
    sc = m.group(6).strip()
    bname = 'b_' + wname
    box_entries.append((bname, sid, sx, sy, sc))
    return f'wire {bname} = {pg_cond}text_box({sid}, px, py, {sx}, {sy}, {sc});\n    wire {wname} = {bname} && shared_text_on;'

ui = pattern.sub(repl_tp, ui)

# Build the single shared text character/font evaluator right before the final color arbiter
sel_lines = [
    '    // -------------------------------------------------------------------------',
    '    // Shared Single-Instance Text & Font Engine (Replaces 80 Parallel Copies)',
    '    // -------------------------------------------------------------------------',
    '    reg [6:0] sel_str_id;',
    '    reg [9:0] sel_start_x;',
    '    reg [8:0] sel_start_y;',
    '    reg [1:0] sel_scale;',
    '    always @(*) begin',
    "        sel_str_id  = 7'd0;",
    "        sel_start_x = 10'd0;",
    "        sel_start_y = 9'd0;",
    "        sel_scale   = 2'd1;"
]
for i, (bname, sid, sx, sy, sc) in enumerate(box_entries):
    kw = 'if' if i == 0 else 'else if'
    sel_lines.append(f'        {kw} ({bname}) begin sel_str_id = {sid}; sel_start_x = {sx}; sel_start_y = {sy}; sel_scale = {sc}; end')
sel_lines.extend([
    '    end',
    '    wire [9:0]  sh_dx   = px - sel_start_x;',
    '    wire [8:0]  sh_dy   = py - sel_start_y;',
    "    wire [9:0]  sh_rx   = (sel_scale == 2'd2) ? (sh_dx >> 1) : sh_dx;",
    "    wire [8:0]  sh_ry   = (sel_scale == 2'd2) ? (sh_dy >> 1) : sh_dy;",
    "    wire [21:0] sh_div6 = sh_rx * 12'd683;",
    '    wire [5:0]  sh_cidx = sh_div6[17:12];',
    "    wire [9:0]  sh_rem6 = sh_rx - (sh_cidx * 10'd6);",
    '    wire [2:0]  sh_ccol = sh_rem6[2:0];',
    '    wire [2:0]  sh_crow = sh_ry[2:0];',
    '    wire [7:0]  sh_ch   = get_char(sel_str_id, sh_cidx);',
    "    wire        shared_text_on = (sh_ccol < 3'd5) && (sh_ch != 8'd0) && font_dot(sh_ch, sh_ccol, sh_crow);",
    ''
])
shared_engine_code = '\n'.join(sel_lines)

arb_marker = '    // -------------------------------------------------------------------------\n    // 最终像素颜色仲裁器 (Clean Hierarchical Priority Multiplexer)'
assert arb_marker in ui, 'arb_marker not found'
ui = ui.replace(arb_marker, shared_engine_code + '\n' + arb_marker, 1)

with open(p_ui, 'w', encoding='utf-8') as f:
    f.write(ui)
print('Updated lcd_ui.v successfully.')

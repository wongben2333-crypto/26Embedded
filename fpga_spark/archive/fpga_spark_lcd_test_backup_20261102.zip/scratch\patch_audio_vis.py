path = r"C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\visualizer\audio_visualizer.v"
with open(path, "r", encoding="utf-8") as f:
    c = f.read()

target1 = """    reg [36:0] bands [0:31];
    reg [36:0] bench [0:31];
    reg [5:0] level_index;
    reg [36:0] level_power;
    reg [7:0] levels [0:127];"""

replacement1 = """    (* syn_ramstyle = "registers" *) reg [36:0] bands [0:31]; /* synthesis syn_ramstyle = "registers" */
    (* syn_ramstyle = "registers" *) reg [36:0] bench [0:31]; /* synthesis syn_ramstyle = "registers" */
    reg [5:0] level_index;
    reg [36:0] level_power;
    (* syn_ramstyle = "registers" *) reg [7:0] levels [0:127]; /* synthesis syn_ramstyle = "registers" */"""

target2 = "work_id <= capture_id; work_peak <= block_peak; block_mean <= block_sum >>> 12;"
replacement2 = "work_id <= capture_id; work_peak <= block_peak; block_mean <= block_sum[27:12];"

c_norm = c.replace("\r\n", "\n")
target1_norm = target1.replace("\r\n", "\n")
target2_norm = target2.replace("\r\n", "\n")

assert target1_norm in c_norm, "target1 not found"
assert target2_norm in c_norm, "target2 not found"

c_norm = c_norm.replace(target1_norm, replacement1.replace("\r\n", "\n"))
c_norm = c_norm.replace(target2_norm, replacement2.replace("\r\n", "\n"))

with open(path, "w", encoding="utf-8", newline="\r\n") as f:
    f.write(c_norm)

print("SUCCESS: audio_visualizer.v patched")

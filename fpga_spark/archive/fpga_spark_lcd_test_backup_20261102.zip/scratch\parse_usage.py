import re

with open(r'C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\scratch\test_60b_build\impl\gwsynthesis\test_60b_syn.rpt.html', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'<a name="usage">.*?(<table.*?>.*?</table>)', text, re.DOTALL)
if m:
    table = m.group(1)
    plain = re.sub(r'<tr.*?>', '\n', table)
    plain = re.sub(r'</t[dh]>', ' | ', plain)
    plain = re.sub(r'<.*?>', '', plain)
    print("=== Resource Usage Summary ===")
    print(plain)

set root [file dirname [info script]]
cd $root
open_project test_60b.gprj
set_option -top_module lcd_test_top
run pnr
exit

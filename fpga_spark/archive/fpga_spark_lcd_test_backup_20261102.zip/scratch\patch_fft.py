path = r"C:\Users\gjl50\Desktop\FPGA\fpga_spark\lcd_test\rtl\visualizer\fft4096.v"
with open(path, "r", encoding="utf-8") as f:
    c = f.read()

target = "ROTATE: begin tr <= rot_r >>> 15; ti <= rot_i >>> 15; state <= SUM; end"
replacement = "ROTATE: begin tr <= rot_r[33:15]; ti <= rot_i[33:15]; state <= SUM; end"

c_norm = c.replace("\r\n", "\n")
assert target in c_norm

c_norm = c_norm.replace(target, replacement)

with open(path, "w", encoding="utf-8", newline="\r\n") as f:
    f.write(c_norm)

print("SUCCESS: fft4096.v patched")
